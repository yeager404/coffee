INSERT INTO users (first_name, last_name, email, password_hash, role, created_at, update_at)
VALUES ('Admin', 'User', 'admin@example.com', '$2a$10$JUvuaUk9w5VwV.uVPUzkKOCCk4QsJzKS8qb95ozj.QbrJE7SqhsF.', 'ADMIN', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
